# JEE 2024 Scraper

Generate a scorecard using NTA keys
